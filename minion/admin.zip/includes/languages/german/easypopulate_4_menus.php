<?php
// $Id: easypopulate_4.php, v4.0.31URI 08-29-2015 mc12345678 $

// $display_output defines

// file uploads display - output via $display_output
define('EASYPOPULATE_4_DISPLAY_MANUFACTURERS', 'Hersteller');
define('EASYPOPULATE_4_DISPLAY_MANUFACTURERS_NONE', 'Kein Hersteller');
define('EASYPOPULATE_4_DISPLAY_FILTERABLE_EXPORTS', 'Filterbare Exporte:');
define('EASYPOPULATE_4_DISPLAY_PRODUCTS_PRICE_EXPORT_OPTION', 'Artikel &amp; Preis Export/Import Optionen:');
define('EASYPOPULATE_4_DISPLAY_COMPLETE_PRODUCTS', '<b>Alle Artikel</b> (mit Metatags falls in der Konfiguration aktiviert)');
define('EASYPOPULATE_4_DISPLAY_COMPLETE_PRODUCTS_SINGLE', '<b>Alle Artikel an master_categories_id (ohne Linked)</b> (mit Metatags)');
define('EASYPOPULATE_4_DISPLAY_PRICE_QTY', '<b>Artikelnummer/Preis/Anzahl</b> (mit Sonderangeboten)');
define('EASYPOPULATE_4_DISPLAY_PRICE_BREAKS', '<b>Artikelnummer/Preis/Staffeklpreise</b>');
define('EASYPOPULATE_4_DISPLAY_FEATURED', '<b>Empfohlene Artikel</b>');
define('EASYPOPULATE_4_DISPLAY_TITLE_CATEGORY','Kategorie Export/Import Optionen');
define('EASYPOPULATE_4_DISPLAY_EXPORT_CATEGORY','Artikelnummer/Kategorie');
define('EASYPOPULATE_4_DISPLAY_EXPORT_CATEGORYMETA','<b>Nur Kategorien</b> (mit Metatags)');
define('EASYPOPULATE_4_DISPLAY_TITLE_ATTRIBUTE','<b>Attribut Export/Import Optionen</b>');
define('EASYPOPULATE_4_DISPLAY_EXPORT_ATTRIBUTE_BASIC','<b>Einfache Attribute</b> (einfach einzeilig)');
define('EASYPOPULATE_4_DISPLAY_EXPORT_ATTRIBUTE_DETAILED','<b>Detaillierte Attribute</b> (detailliert mehrzeilig)');
define('EASYPOPULATE_4_DISPLAY_EXPORT_DETAILED_SBA', '<b>Detaillierte Stock By Attributes Daten</b> (detailliert mehrzeilig)');
define('EASYPOPULATE_4_DISPLAY_EXPORT_SBA_STOCK', '<b>Lagerbest�nde f�r Artikel mit Atributen</b>');
define('EASYPOPULATE_4_DISPLAY_EXPORT_SBA_STOCK_ASC', '<b>Lagerbest�nde f�r Artikel mit Attributen aufsteigend sortiert</b>');
define('EASYPOPULATE_4_DISPLAY_TITLE_EXPORT_ONLY', '<b>DIAGNOSE EXPORTE - ACHTUNG: NICHT GEEIGNET ZUM IMPORT VON ATTRIBUTEN!</b>');
define('EASYPOPULATE_4_DISPLAY_EXPORT_OPTION_NAMES', '<b>Attributnamen</b>');
define('EASYPOPULATE_4_DISPLAY_EXPORT_OPTION_VALUES', '<b>Attributwerte</b>');
define('EASYPOPULATE_4_DISPLAY_EXPORT_OPTION_NAMES_TO_VALUES', '<b>Zurdnung der Attributwerte zu den Attributnamen</b>');
