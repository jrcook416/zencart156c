<?php
/**
 * This file has been added to support the possibility of discovering the current version of Easypopulate 4 (EP4) that is installed.
 *   The intent to be met is to discover the version information from outside of EP4 and instead of populating the database with
 *   an additional constant or adding a define style file that likely would be loaded on each page load.
 * @ author mc12345678
 * @ New file added 2019-01-10 by mc12345678: https://mc12345678.com
 */
 
 $curver_detail = '4.0.37.13';
 
