<?php
// $Id: easypopulate_4_tools_dhtml.php, v4.0.21 06-01-2012 chadderuski $
// Note: This file is only for zencart version prior to v1.5
$za_contents[] = array('text' => BOX_TOOLS_EASYPOPULATE_4, 'link' => zen_href_link(FILENAME_EASYPOPULATE_4, '', 'NONSSL'));
